# Find Security Bugs - Command Line Version

The latest package version is made available in the release section : https://github.com/find-sec-bugs/find-sec-bugs/releases

## Building the package

```
gradle copyRuntimeLibs
```

The spotbugs dependencies and the latest FindSecurityBugs plugin will be place in the lib directory.