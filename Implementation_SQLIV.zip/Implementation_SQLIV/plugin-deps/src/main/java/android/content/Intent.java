package android.content;

public class Intent {

    public Intent setAction(String action) {
        return this;
    }

    public Intent putExtra (String name, CharSequence value) {
        return this;
    }
}
