package android.database;

public class SQLException
        extends RuntimeException
{
    public SQLException()
    {
        throw new RuntimeException("Stub!");
    }

    public SQLException(String error)
    {
        throw new RuntimeException("Stub!");
    }

    public SQLException(String error, Throwable cause)
    {
        throw new RuntimeException("Stub!");
    }
}
