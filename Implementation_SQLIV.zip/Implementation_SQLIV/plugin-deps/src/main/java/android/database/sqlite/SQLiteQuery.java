package android.database.sqlite;

public final class SQLiteQuery
        extends SQLiteProgram
{
    SQLiteQuery()
    {
        throw new RuntimeException("Stub!");
    }

    public String toString()
    {
        throw new RuntimeException("Stub!");
    }
}
