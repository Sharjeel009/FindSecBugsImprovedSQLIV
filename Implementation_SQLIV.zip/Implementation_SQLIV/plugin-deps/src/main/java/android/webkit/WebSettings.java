package android.webkit;

public abstract class WebSettings {
    public abstract void setJavaScriptEnabled (boolean flag);
}
