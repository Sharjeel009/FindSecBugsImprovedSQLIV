package com.hazelcast.config;

public class SymmetricEncryptionConfig {
    public void setAlgorithm(String algorithm) {
    }

    public void setSalt(String salt) {
    }

    public void setPassword(String password) {
    }

    public void setIterationCount(int iterationCount) {
    }
}
