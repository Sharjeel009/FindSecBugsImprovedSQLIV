package com.hazelcast.core;

import com.hazelcast.config.Config;

public class Hazelcast {

    public static void init(Config config) {

    }

    public static IMap getMap(String idMap) {
        return null;
    }
}
