package com.opensymphony.xwork2.util;

public class OgnlTextParser implements TextParser {

    public Object evaluate(char[] openChars, String expression, TextParseUtil.ParsedValueEvaluator evaluator, int maxLoopCount) {
        return null;
    }
}
