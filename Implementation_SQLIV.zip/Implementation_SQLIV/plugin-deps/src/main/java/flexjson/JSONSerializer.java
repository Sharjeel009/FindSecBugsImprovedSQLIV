package flexjson;

public class JSONSerializer {
}
