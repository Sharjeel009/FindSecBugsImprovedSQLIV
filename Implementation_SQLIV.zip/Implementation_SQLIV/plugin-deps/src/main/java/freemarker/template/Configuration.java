package freemarker.template;

public class Configuration {


    public Template getTemplate(String s) {
        return null;
    }

}
