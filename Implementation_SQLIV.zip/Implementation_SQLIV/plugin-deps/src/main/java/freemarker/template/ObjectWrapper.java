package freemarker.template;

public interface ObjectWrapper {
}
