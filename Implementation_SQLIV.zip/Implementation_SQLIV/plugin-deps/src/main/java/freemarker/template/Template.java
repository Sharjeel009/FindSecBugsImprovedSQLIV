package freemarker.template;

import java.io.IOException;
import java.io.Writer;

public class Template {

    public void process(Object dataModel, Writer out) throws TemplateException, IOException {

    }

    public void process(Object dataModel, Writer out, ObjectWrapper wrapper, TemplateNodeModel rootNode)
            throws TemplateException, IOException {

    }

    public void process(Object dataModel, Writer out, ObjectWrapper wrapper)
            throws TemplateException,
            IOException {

    }
}
