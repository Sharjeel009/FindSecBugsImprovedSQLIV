package freemarker.template;

public class TemplateException extends Exception {
}
