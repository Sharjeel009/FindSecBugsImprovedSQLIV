package freemarker.template;

public interface TemplateNodeModel {
    
}
