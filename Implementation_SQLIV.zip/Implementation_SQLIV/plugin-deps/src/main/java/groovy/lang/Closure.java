package groovy.lang;

public abstract class Closure<V> {

    public V call() {
        return null;
    }

    public V call(Object... args) {
        return null;
    }

    public V call(Object arguments) {
        return null;
    }
}
