package javax.el;

public abstract class ELContext {
    public abstract ELResolver getELResolver();
}
