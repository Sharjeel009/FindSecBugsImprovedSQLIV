package javax.el;

public abstract class ELResolver {
}
