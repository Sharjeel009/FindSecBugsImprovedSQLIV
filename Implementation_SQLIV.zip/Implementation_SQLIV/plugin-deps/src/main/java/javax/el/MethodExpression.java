package javax.el;

public abstract class MethodExpression {
}
