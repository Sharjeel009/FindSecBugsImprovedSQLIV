package javax.el;

public abstract class ValueExpression {
    public abstract Object getValue(ELContext context);
}
