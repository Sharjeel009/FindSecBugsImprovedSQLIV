package javax.faces.application;

import javax.el.ExpressionFactory;

public abstract class Application {

    public ExpressionFactory getExpressionFactory() {
        return null;
    }
}
