package javax.jdo;

public interface Extent<E> extends Iterable<E> {

}
