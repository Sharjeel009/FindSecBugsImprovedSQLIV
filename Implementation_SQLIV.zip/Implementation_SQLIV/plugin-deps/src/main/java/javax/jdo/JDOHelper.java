package javax.jdo;

public class JDOHelper {
    public static PersistenceManagerFactory getPersistenceManagerFactory(String s) {
        return null;
    }
}
