package javax.persistence;

public @interface Id {
}
