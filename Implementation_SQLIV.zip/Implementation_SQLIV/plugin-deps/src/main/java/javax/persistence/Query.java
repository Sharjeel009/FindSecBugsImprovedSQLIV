package javax.persistence;

public interface Query {
}
