package javax.persistence.criteria;

public interface CriteriaQuery<T> {
}
