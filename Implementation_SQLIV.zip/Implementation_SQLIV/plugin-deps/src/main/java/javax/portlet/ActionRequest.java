package javax.portlet;

public interface ActionRequest {
}
