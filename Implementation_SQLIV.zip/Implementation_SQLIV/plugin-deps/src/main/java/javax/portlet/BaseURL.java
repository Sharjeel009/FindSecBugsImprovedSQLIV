package javax.portlet;

public interface BaseURL {
}
