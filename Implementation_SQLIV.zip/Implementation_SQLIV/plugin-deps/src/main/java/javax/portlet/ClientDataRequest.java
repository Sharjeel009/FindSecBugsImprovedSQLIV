package javax.portlet;

public interface ClientDataRequest {
}
