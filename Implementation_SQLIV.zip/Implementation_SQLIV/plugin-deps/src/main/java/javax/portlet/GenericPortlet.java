package javax.portlet;

import java.io.IOException;

public class GenericPortlet {

    public void init (PortletConfig portletConfig) throws PortletException {

    }
}
