package javax.portlet;

public interface PortletConfig {
}
