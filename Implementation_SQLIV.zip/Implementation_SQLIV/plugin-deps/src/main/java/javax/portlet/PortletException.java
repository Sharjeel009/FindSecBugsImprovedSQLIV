package javax.portlet;

public class PortletException extends Exception {
}
