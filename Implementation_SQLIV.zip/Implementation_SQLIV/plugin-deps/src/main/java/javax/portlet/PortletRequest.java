package javax.portlet;

public interface PortletRequest {
}
