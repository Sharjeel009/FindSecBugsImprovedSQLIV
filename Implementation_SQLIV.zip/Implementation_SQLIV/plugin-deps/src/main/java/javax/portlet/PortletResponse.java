package javax.portlet;

public interface PortletResponse {
}
