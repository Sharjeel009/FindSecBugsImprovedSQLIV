package javax.portlet;

public interface RenderRequest {

    String getParameter(String name);
}
