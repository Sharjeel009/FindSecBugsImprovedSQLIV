package javax.portlet;

public interface ResourceRequest {
}
