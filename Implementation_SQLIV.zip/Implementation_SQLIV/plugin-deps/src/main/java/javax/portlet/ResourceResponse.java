package javax.portlet;

public interface ResourceResponse {
}
