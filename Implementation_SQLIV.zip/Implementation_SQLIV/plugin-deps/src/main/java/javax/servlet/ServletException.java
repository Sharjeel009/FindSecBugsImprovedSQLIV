package javax.servlet;

public class ServletException extends Exception {
}
