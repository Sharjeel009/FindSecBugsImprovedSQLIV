package javax.servlet.jsp;

public class JspException extends Exception {
}
