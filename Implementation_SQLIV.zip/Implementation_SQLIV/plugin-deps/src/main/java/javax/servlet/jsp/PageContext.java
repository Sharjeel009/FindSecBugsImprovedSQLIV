package javax.servlet.jsp;

public abstract class PageContext {
}
