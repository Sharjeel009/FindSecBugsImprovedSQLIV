package javax.servlet.jsp.tagext;

import javax.servlet.jsp.JspWriter;

public abstract class BodyContent extends JspWriter {
}
