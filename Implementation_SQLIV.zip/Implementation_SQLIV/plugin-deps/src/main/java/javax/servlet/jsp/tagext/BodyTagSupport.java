package javax.servlet.jsp.tagext;

import javax.servlet.jsp.JspException;

public class BodyTagSupport extends TagSupport implements BodyTag {

    @Override
    public void setBodyContent(BodyContent var1) {

    }

    @Override
    public void doInitBody() throws JspException {

    }
}
