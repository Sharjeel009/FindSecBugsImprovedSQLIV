package javax.ws.rs;

public @interface GET {
}
