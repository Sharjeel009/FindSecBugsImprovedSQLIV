package javax.ws.rs;

public @interface Path {

    String value();
}
