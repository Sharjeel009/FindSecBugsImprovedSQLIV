package javax.ws.rs;

public @interface PathParam {

    String value();
}
