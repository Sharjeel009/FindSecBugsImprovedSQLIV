package javax.ws.rs.core;

public class NewCookie {
}
