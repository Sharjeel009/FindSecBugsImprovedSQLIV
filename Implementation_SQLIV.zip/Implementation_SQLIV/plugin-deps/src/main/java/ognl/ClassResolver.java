package ognl;

public interface ClassResolver {
}
