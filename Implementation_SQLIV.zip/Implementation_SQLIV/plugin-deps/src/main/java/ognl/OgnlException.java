package ognl;

public class OgnlException extends Exception {
}
