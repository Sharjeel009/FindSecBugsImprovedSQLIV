package org.acegisecurity.context;

public interface GrantedAuthority {
}
