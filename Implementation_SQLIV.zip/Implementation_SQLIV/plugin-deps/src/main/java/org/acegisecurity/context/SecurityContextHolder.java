package org.acegisecurity.context;

public class SecurityContextHolder {
    public static SecurityContext getContext() {
        return null;
    }

    public static void setContext(SecurityContext context) {
    }
}
