package org.apache.commons.beanutils;

import java.util.Map;

public class BeanUtils {

    public static void populate(Object bean, Map properties) {

    }
}
