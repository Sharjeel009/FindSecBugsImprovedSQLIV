package org.apache.commons.beanutils;

import java.util.Map;

public class BeanUtilsBean {

    public synchronized static BeanUtilsBean getInstance() {
        return (BeanUtilsBean) null;
    }

    public void populate(Object bean, Map properties) {

    }
}
