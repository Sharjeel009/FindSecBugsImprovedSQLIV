package org.apache.commons.codec.binary;

import java.nio.ByteBuffer;

public class Hex {

    public static char[] encodeHex(final byte[] data) {
        return null;
    }

    public static char[] encodeHex(final ByteBuffer data) {
        return null;
    }

    public static char[] encodeHex(final byte[] data, final boolean toLowerCase) {
        return null;
    }

    public static char[] encodeHex(final ByteBuffer data, final boolean toLowerCase) {
        return null;
    }

    public static String encodeHexString(final byte[] data) {
        return null;
    }

    public static String encodeHexString(final byte[] data, boolean toLowerCase) {
        return null;
    }

    public static String encodeHexString(final ByteBuffer data) {
        return null;
    }

    public static String encodeHexString(final ByteBuffer data, boolean toLowerCase) {
        return null;
    }

    public byte[] encode(final byte[] array) {
        return null;
    }

    public byte[] encode(final ByteBuffer array) {
        return null;
    }


}
