package org.apache.commons.collections;

public interface Transformer {
    Object transform(Object input);
}
