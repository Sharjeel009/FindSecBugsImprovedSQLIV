package org.apache.commons.fileupload;

public interface FileItem {

    public String getName();
}
