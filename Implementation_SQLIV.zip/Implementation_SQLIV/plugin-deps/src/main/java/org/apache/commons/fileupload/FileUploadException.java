package org.apache.commons.fileupload;

public class FileUploadException extends Exception {
}
