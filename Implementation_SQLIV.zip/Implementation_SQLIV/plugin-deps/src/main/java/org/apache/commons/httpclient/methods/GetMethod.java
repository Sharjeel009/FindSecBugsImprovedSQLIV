package org.apache.commons.httpclient.methods;

public class GetMethod {

    public GetMethod() {
    }

    public GetMethod(String uri) {
    }

    public void setQueryString(String queryString) {
    }
}
