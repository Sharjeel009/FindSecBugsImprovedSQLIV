//Stub class part of the dependencies already.. Uncommented when necessary

//package org.apache.commons.lang;
//
//public class StringEscapeUtils {
//
//    public static final String escapeCsv(final String input) {
//        return null;
//    }
//
//    public static final String unescapeCsv(final String input) {
//        return null;
//    }
//
//    public static final String escapeHtml(final String input) {
//        return null;
//    }
//
//    public static final String unescapeHtml(final String input) {
//        return null;
//    }
//
//    public static final String escapeJava(final String input) {
//        return null;
//    }
//
//    public static final String unescapeJava(final String input) {
//        return null;
//    }
//
//    public static final String escapeJavaScript(final String input) {
//        return null;
//    }
//
//    public static final String unescapeJavaScript(final String input) {
//        return null;
//    }
//
//    public static final String escapeSql(final String input) {
//        return null;
//    }
//
//    public static final String escapeXml(final String input) {
//        return null;
//    }
//}
