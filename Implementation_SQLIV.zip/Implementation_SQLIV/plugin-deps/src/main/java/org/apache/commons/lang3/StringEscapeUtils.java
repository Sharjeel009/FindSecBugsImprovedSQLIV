package org.apache.commons.lang3;

public class StringEscapeUtils {

    //StringEscapeUtils version 3.1 API

    public static String escapeCsv(String input) {
        return "safe";
    }

    public static String escapeEcmaScript(String input) {
        return "safe";
    }

    public static String escapeHtml3(String input) {
        return "safe";
    }

    public static String escapeHtml4(String input) {
        return "safe";
    }

    public static String escapeJava(String input) {
        return "safe";
    }

    public static String escapeJson(String input) {
        return "safe";
    }

    public static String escapeXml(String input) {
        return "safe";
    }

    public static String escapeXml10(String input) {
        return "safe";
    }

    public static String escapeXml11(String input) {
        return "safe";
    }


    public static String unescapeCsv(String input) {
        return "safe";
    }

    public static String unescapeEcmaScript(String input) {
        return "safe";
    }

    public static String unescapeHtml3(String input) {
        return "safe";
    }

    public static String unescapeHtml4(String input) {
        return "safe";
    }

    public static String unescapeJava(String input) {
        return "safe";
    }

    public static String unescapeJson(String input) {
        return "safe";
    }

    public static String unescapeXml(String input) {
        return "safe";
    }
}
