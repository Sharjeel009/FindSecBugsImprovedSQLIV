package org.apache.commons.mail;

public class HtmlEmail extends MultiPartEmail {

}
