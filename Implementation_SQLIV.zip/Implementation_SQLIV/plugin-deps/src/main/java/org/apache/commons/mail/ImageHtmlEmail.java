package org.apache.commons.mail;

public class ImageHtmlEmail extends HtmlEmail {

}
