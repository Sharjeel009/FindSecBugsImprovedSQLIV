package org.apache.commons.mail;

public class MultiPartEmail extends Email {

}
