package org.apache.commons.mail;

public class SimpleEmail extends Email {

}
