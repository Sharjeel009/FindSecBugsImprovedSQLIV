package org.apache.commons.text;

public class StringEscapeUtils {
    public static final String escapeJava(final String input) {
        return null;
    }

    public static final String escapeEcmaScript(final String input) {
        return null;
    }

    public static final String escapeJson(final String input) {
        return null;
    }

    public static final String unescapeJava(final String input) {
        return null;
    }

    public static final String unescapeEcmaScript(final String input) {
        return null;
    }

    public static final String unescapeJson(final String input) {
        return null;
    }

    public static final String escapeHtml4(final String input) {
        return null;
    }

    public static final String escapeHtml3(final String input) {
        return null;
    }

    public static final String unescapeHtml4(final String input) {
        return null;
    }

    public static final String unescapeHtml3(final String input) {
        return null;
    }

    public static String escapeXml10(final String input) {
        return null;
    }

    public static String escapeXml11(final String input) {
        return null;
    }

    public static final String unescapeXml(final String input) {
        return null;
    }

    public static final String escapeCsv(final String input) {
        return null;
    }

    public static final String unescapeCsv(final String input) {
        return null;
    }

    public static final String escapeXSI(final String input) {
        return null;
    }

    public static final String unescapeXSI(final String input) {
        return null;
    }
}