package org.apache.http.client;

public interface HttpClient {

}
