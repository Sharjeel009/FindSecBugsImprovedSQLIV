package org.apache.http.client.methods;

public class HttpGet {

    public HttpGet(final String uri) {
    }   
}
