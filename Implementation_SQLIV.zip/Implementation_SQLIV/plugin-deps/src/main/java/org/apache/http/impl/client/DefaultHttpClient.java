/**
 * 
 */
package org.apache.http.impl.client;

import org.apache.http.client.HttpClient;

/**
 * @author xsun
 *
 */
public class DefaultHttpClient implements HttpClient {

  /**
   * 
   */
  public DefaultHttpClient() {
    // TODO Auto-generated constructor stub
  }

}
