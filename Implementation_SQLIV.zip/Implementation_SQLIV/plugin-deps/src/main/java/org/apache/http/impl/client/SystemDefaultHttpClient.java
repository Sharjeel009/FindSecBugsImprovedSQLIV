package org.apache.http.impl.client;

public class SystemDefaultHttpClient extends DefaultHttpClient {

  public SystemDefaultHttpClient() {
    // TODO Auto-generated constructor stub
  }

}
