package org.apache.jetspeed.portlet;

public abstract class PortletAdapter {

    public void init(PortletConfig config) throws UnavailableException {

    }
}
