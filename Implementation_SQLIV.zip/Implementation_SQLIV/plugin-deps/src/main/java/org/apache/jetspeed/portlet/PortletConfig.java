package org.apache.jetspeed.portlet;

public interface PortletConfig {
}
