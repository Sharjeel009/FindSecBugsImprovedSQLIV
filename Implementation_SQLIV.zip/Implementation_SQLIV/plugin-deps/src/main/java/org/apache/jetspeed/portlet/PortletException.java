package org.apache.jetspeed.portlet;

public class PortletException extends Exception {
}
