package org.apache.jetspeed.portlet;

public interface PortletRequest {
    String getParameter(String name);
}
