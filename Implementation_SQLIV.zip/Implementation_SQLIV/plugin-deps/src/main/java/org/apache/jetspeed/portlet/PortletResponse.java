package org.apache.jetspeed.portlet;

import javax.servlet.http.HttpServletResponse;

public interface PortletResponse extends HttpServletResponse {

}
