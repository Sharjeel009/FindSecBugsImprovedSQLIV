package org.apache.jetspeed.portlet;

public class UnavailableException extends Exception {
}
