package org.apache.struts.action;

public class ActionErrors extends ActionMessages {
}
