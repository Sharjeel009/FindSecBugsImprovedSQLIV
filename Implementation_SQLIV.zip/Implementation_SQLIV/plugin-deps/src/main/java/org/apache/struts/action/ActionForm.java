package org.apache.struts.action;

public class ActionForm {
}
