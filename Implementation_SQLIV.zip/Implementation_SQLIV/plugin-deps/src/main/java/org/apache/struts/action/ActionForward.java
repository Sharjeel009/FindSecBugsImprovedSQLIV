package org.apache.struts.action;

public class ActionForward {

    public ActionForward() {
    }

    public ActionForward(String path) {
    }

    public ActionForward(String path, boolean redirect) {
    }

    public ActionForward(String name, String path, boolean redirect) {
    }

    public ActionForward(String name, String path, boolean redirect,
                         boolean contextRelative) {
    }

    public void setPath(String path) {
    }
}
