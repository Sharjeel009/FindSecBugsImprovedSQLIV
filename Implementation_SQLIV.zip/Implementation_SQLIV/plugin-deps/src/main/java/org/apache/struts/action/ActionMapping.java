package org.apache.struts.action;

public class ActionMapping {
    public ActionForward findForward(String success) {
        return null;
    }
}
