package org.apache.struts.action;

public class ActionMessage {
    public ActionMessage(String message) {
    }
}
