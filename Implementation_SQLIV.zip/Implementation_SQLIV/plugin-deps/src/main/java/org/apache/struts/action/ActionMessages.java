package org.apache.struts.action;

import java.io.Serializable;

public class ActionMessages implements Serializable {

    public void add(String property, ActionMessage message) {

    }
}
