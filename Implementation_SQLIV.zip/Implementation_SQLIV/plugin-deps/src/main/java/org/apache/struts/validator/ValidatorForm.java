package org.apache.struts.validator;

public class ValidatorForm {
}
