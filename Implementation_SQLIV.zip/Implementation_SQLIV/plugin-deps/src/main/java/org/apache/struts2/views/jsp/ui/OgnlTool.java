package org.apache.struts2.views.jsp.ui;


public class OgnlTool {

    public Object findValue(String expr, Object context) {
        return null;
    }
}
