package org.apache.tapestry5.annotations;

public @interface OnEvent {
    String value();

    String component();
}
