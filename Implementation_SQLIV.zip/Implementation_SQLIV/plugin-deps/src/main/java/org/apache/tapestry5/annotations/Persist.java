package org.apache.tapestry5.annotations;

public @interface Persist {
}
