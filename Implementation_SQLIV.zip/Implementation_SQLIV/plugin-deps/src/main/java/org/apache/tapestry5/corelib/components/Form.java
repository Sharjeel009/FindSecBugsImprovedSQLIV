package org.apache.tapestry5.corelib.components;

public class Form {
    public void recordError(String errorMessage) {
    }
}
