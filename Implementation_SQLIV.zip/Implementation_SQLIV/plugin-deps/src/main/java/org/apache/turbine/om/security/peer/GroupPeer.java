package org.apache.turbine.om.security.peer;

import org.apache.turbine.om.peer.BasePeer;

public class GroupPeer extends BasePeer {
}
