package org.apache.turbine.util.db;

import java.io.Serializable;
import java.util.Map;

public class Criteria {
}
