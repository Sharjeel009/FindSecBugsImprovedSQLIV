package org.apache.velocity;

import org.apache.velocity.context.Context;

public class VelocityContext implements Context {

    /**
     * This is not the actual structure of velocity. It has a abstract class holding this method.
     * @param name
     * @param velocity
     */
    public void put(String name, String velocity) {

    }
}
