package org.apache.velocity.context;

public interface Context {
}
