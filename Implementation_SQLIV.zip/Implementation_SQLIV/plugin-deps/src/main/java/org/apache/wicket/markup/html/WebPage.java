package org.apache.wicket.markup.html;

public class WebPage {
}
