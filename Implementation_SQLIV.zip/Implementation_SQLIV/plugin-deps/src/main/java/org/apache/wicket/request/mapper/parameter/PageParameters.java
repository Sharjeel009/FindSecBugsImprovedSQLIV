package org.apache.wicket.request.mapper.parameter;

import java.util.LinkedHashMap;

public class PageParameters extends LinkedHashMap<String, String> {
    public Long getAsLong(String key) {
        return null;
    }

}
