package org.apache.wicket.util.upload;

public interface FileItem {

    public String getName();
}
