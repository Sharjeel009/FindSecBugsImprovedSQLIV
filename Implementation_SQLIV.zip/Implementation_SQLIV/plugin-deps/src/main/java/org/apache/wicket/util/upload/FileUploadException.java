package org.apache.wicket.util.upload;

public class FileUploadException extends Exception {
}
