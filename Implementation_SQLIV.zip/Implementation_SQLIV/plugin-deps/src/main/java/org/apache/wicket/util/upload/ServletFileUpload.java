package org.apache.wicket.util.upload;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public class ServletFileUpload {
    public List<FileItem> parseRequest(HttpServletRequest req) {
        return null;
    }
}
