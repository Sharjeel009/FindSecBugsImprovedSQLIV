package org.hibernate;

public interface SessionFactory {
    Session openSession();
}
