package org.hibernate.criterion;

public interface Criterion {
}
