package org.hibernate.type;

public class StandardBasicTypes {
    public static final StringType STRING = new StringType();
}
