package org.hibernate.type;

public class StringType implements Type {
}
