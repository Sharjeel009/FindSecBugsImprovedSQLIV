package org.hibernate.type;

public interface Type {
}
