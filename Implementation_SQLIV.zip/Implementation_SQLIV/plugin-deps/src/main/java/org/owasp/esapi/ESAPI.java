package org.owasp.esapi;

public class ESAPI {

    public static Validator validator() {
        return null;
    }

    public static Encoder encoder() {
        return null;
    }

    public static Encryptor encryptor() {
        return null;
    }
}
