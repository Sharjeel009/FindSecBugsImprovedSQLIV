package org.owasp.esapi.crypto;

public class CipherText {
}
