package org.owasp.esapi.crypto;

public class PlainText {
    public PlainText(byte[] value) {}

    public PlainText(String value) {}
}
