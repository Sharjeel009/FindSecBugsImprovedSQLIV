package org.owasp.esapi.errors;

public class EncryptionException extends Exception {

}
