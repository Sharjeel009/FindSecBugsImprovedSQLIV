package org.owasp.esapi.errors;

public class IntrusionException extends Exception {
}
