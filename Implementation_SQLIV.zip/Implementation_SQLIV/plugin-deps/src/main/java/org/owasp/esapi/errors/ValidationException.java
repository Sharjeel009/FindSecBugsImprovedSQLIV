package org.owasp.esapi.errors;

public class ValidationException extends Exception {
}
