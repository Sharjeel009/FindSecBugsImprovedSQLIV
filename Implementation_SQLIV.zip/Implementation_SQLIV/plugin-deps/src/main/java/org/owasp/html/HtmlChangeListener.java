package org.owasp.html;

public interface HtmlChangeListener<T> {
}
