package org.owasp.html;

public final class PolicyFactory {

    public <CTX> String sanitize(String html, HtmlChangeListener<CTX> listener, CTX context) {
        return "";
    }
}
