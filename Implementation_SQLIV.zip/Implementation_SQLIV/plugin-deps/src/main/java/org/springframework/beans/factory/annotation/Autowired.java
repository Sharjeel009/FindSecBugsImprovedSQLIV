package org.springframework.beans.factory.annotation;

public @interface Autowired {
}
