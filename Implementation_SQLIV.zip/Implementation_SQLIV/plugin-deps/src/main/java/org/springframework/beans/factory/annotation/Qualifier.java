package org.springframework.beans.factory.annotation;

public @interface Qualifier {
}
