package org.springframework.dao;

public abstract class DataAccessException extends Exception {

}
