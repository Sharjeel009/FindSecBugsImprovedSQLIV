package org.springframework.expression;

public class ExpressionException extends RuntimeException {
}
