package org.springframework.expression;

public class ParseException extends ExpressionException {
}
