package org.springframework.expression;

public interface ParserContext {
}
