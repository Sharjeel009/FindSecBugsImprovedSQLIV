package org.springframework.expression.spel.standard;

import org.springframework.expression.common.TemplateAwareExpressionParser;

public class SpelExpressionParser extends TemplateAwareExpressionParser {

    public SpelExpressionParser() {

    }
}
