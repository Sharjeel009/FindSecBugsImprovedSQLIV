package org.springframework.expression.spel.support;

import org.springframework.expression.EvaluationContext;

public class StandardEvaluationContext implements EvaluationContext {

    public StandardEvaluationContext() {

    }

    public StandardEvaluationContext(Object rootObject) {

    }
}
