package org.springframework.jdbc.core;

import java.util.ArrayList;

public class BatchUpdateUtils {
    public static void executeBatchUpdate(String sql, ArrayList<Object[]> batchValues, int[] columnTypes, JdbcOperations jdbcOperations) {

    }


}
