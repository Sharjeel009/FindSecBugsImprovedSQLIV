package org.springframework.jdbc.core;

public interface PreparedStatementCallback<T> {
}
