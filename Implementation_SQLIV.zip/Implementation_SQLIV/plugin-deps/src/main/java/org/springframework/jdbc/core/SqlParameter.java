package org.springframework.jdbc.core;

public class SqlParameter {
}
