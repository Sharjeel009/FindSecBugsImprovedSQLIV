package org.springframework.jdbc.core;

public interface StatementCallback<T> {
}
