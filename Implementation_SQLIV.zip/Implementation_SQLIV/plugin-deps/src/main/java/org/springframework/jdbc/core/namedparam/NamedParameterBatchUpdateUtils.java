package org.springframework.jdbc.core.namedparam;

import org.springframework.jdbc.core.JdbcOperations;

import java.util.ArrayList;

public class NamedParameterBatchUpdateUtils {

    public static void executeBatchUpdate(String sql, ArrayList<Object[]> batchValues, int[] columnTypes, JdbcOperations jdbcOperations) {

    }
}
