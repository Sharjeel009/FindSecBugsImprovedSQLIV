package org.springframework.jdbc.support.rowset;

public interface SqlRowSet {
}
