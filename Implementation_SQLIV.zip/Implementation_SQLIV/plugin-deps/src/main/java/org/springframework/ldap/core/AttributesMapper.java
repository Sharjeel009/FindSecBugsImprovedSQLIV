package org.springframework.ldap.core;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

public interface AttributesMapper <T> {

}
