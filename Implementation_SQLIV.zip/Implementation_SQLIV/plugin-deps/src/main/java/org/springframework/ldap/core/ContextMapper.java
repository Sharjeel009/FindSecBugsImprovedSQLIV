package org.springframework.ldap.core;

import javax.naming.Binding;
import javax.naming.NamingException;
import javax.naming.directory.SearchResult;

public interface ContextMapper <T> {

//    T mapFromContext(Object ctx) throws NamingException;

}
