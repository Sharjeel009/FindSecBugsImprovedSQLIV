package org.springframework.ldap.core;

public class LdapEntryIdentification {
}
