package org.springframework.ldap.core;

public class LdapEntryIdentificationContextMapper implements ContextMapper<LdapEntryIdentification> {
}
