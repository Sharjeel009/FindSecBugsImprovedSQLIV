package org.springframework.ldap.core;

import javax.naming.NameClassPair;
import javax.naming.NamingException;

public interface NameClassPairCallbackHandler {

}
