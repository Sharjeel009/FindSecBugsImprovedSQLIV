package org.springframework.ldap.core;

public interface NameClassPairMapper<T> {

}
