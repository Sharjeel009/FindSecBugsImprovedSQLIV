package org.springframework.ldap.core.support;

import org.springframework.ldap.core.NameClassPairCallbackHandler;

public class CountNameClassPairCallbackHandler implements NameClassPairCallbackHandler {
}
