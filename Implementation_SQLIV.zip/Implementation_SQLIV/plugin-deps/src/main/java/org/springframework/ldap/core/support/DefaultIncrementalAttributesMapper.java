package org.springframework.ldap.core.support;

import org.springframework.ldap.core.IncrementalAttributesMapper;

public class DefaultIncrementalAttributesMapper implements IncrementalAttributesMapper<DefaultIncrementalAttributesMapper> {
}
