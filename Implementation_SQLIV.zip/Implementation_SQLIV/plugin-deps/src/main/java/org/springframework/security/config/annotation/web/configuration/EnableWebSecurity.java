package org.springframework.security.config.annotation.web.configuration;

public @interface EnableWebSecurity {
}
