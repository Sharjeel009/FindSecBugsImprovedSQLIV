package org.springframework.security.config.annotation.web.configurers;

abstract class AbstractHttpConfigurer {

    public void disable() {
    }

}
