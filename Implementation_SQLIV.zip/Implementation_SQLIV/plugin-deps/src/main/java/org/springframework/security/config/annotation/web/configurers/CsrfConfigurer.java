package org.springframework.security.config.annotation.web.configurers;

public final class CsrfConfigurer extends AbstractHttpConfigurer {

}
