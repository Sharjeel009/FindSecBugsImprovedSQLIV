package org.springframework.security.core;

public interface GrantedAuthority {
}
