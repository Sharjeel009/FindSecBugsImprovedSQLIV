package org.springframework.security.core.context;

public class SecurityContextHolder {
    public static SecurityContext getContext() {
        return null;
    }

    public static void setContext(SecurityContext context) {
    }
}
