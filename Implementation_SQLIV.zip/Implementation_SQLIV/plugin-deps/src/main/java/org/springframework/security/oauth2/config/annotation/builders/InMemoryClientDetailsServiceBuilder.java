package org.springframework.security.oauth2.config.annotation.builders;

public class InMemoryClientDetailsServiceBuilder extends
        ClientDetailsServiceBuilder<InMemoryClientDetailsServiceBuilder> {

}
