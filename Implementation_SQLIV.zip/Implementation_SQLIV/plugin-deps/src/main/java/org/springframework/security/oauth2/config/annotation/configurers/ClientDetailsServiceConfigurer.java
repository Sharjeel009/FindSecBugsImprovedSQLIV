package org.springframework.security.oauth2.config.annotation.configurers;

import org.springframework.security.oauth2.config.annotation.builders.InMemoryClientDetailsServiceBuilder;

public class ClientDetailsServiceConfigurer {

    public InMemoryClientDetailsServiceBuilder inMemory() throws Exception { return null; }
}
