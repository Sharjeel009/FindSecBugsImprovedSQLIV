package org.springframework.security.oauth2.config.annotation.web.configuration;

public @interface EnableAuthorizationServer {
}
