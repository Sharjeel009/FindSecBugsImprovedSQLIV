package org.springframework.security.oauth2.provider;

public interface ClientDetailsService {
}
