package org.springframework.stereotype;

public @interface Controller {
}
