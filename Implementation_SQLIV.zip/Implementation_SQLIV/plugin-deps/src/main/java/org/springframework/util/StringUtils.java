package org.springframework.util;

public abstract class StringUtils {
}
