package org.springframework.validation;

public interface Errors {
}
