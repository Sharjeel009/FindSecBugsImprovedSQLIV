package org.springframework.web.bind.annotation;

public @interface GetMapping {
    String value();
}
