package org.springframework.web.context.request;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletRequestAttributes {
    public ServletRequestAttributes(HttpServletRequest req, HttpServletResponse res) {

    }

    public void requestCompleted() {

    }
}
