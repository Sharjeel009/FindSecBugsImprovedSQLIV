package org.springframework.web.servlet.tags;

public interface ParamAware {

    void addParam(Param param);
}
