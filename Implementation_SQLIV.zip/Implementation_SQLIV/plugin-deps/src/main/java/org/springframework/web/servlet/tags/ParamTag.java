package org.springframework.web.servlet.tags;

import javax.servlet.jsp.tagext.BodyTagSupport;

public class ParamTag extends BodyTagSupport {
}
