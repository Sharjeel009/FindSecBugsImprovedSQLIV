package org.springframework.web.servlet.tags;

public class ThemeTag extends MessageTag {

}
