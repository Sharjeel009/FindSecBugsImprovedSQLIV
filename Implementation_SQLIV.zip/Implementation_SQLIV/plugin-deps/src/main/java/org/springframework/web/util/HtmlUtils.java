package org.springframework.web.util;

public class HtmlUtils {

    public static String htmlEscape(String param) {
        return null;
    }
}
