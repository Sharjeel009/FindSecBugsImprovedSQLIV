package org.springframework.web.util;

public class JavaScriptUtils {

    public static String javaScriptEscape(String input) {
        return "";
    }
}
