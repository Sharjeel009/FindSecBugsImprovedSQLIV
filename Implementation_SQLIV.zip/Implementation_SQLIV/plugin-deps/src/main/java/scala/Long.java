package scala;

public class Long {
}
