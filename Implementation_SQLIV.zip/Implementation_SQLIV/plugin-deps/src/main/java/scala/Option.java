package scala;

public abstract class Option {
}
