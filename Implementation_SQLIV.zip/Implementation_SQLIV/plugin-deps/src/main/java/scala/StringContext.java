package scala;

public class StringContext {
}
