package scala;

public class Tuple2 {
}
