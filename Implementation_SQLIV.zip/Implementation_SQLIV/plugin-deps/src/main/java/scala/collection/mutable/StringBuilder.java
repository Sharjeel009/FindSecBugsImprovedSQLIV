package scala.collection.mutable;

public class StringBuilder {
}
