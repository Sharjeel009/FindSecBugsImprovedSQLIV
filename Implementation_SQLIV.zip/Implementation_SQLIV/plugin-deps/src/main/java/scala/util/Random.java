package scala.util;

/**
 * Mock of the following class.
 * http://www.scala-lang.org/api/current/#scala.util.Random
 *
 *
 * Use to identify unsecure random generator.
 */
public class Random {

    public Random() {

    }

    public Random(scala.Long seed) {

    }
}
