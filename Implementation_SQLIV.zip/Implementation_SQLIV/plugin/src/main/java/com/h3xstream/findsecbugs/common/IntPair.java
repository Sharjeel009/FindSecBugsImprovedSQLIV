package com.h3xstream.findsecbugs.common;

public class IntPair {

    int first;
    int second;

    public IntPair() {
    }

    public IntPair(int first, int second)
    {
        this.first = first;
        this.second = second;
    }

    public int getFirst() {
        return first;
    }

    public void setFirst(int first) {
        this.first = first;
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int second) {
        this.second = second;
    }
}
