package com.h3xstream.findsecbugs.common;

import edu.umd.cs.findbugs.ba.BasicBlock;

public class ProcessBasicBlock
{
    BasicBlock oBasicBlock = null;
    boolean addChildren = false;

}
