package com.h3xstream.findsecbugs.common;

public class VarTypes {

    public final static int INT_TYPE = 0;
    public final static int BOOLEAN_TYPE = 1;
    public final static int STRING_TYPE = 2;
    public final static int ARRAY_TYPE = 3;

}
